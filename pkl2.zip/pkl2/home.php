  <style type="text/css">


  .logo {
    height: 150px;
    width: 250px;
    margin-bottom: 5px;
  }


  .logo >  img{
    height: 100%;  
    width: 100%;

} 
.morecontent span {
    display: none;
}
.morelink {
    display: block;
}
.rows {
        width: 100%;
        height: 50%;
        
    }
    img {
        width: 100%;
        height: 50%;
    }
	.title-logo:hover {
  color: yellow; 
  text-decoration:none; 
}
.title-logo   img {
  width: 100%;
  height: 300px;
}
 </style> 
   <div class="col-md-15 col-md-offset--2 " >  
   <!-- <div class="col-md-12"> -->
    <div class="rows "> 
     <p style="margin-top: 10px;" class="title-logo"> 
        <a  class=""  href="<?php echo web_root; ?>index.php" title="">
           <img src="theme/download.jpg"  alt="logo"  />
        </a>
    </p> 
     </div>    
   </div>

   <div>
  <section id="call-to-action-2" style="background: white;font-family:Segoe UI; font-size: 20px;">
    <div class="container">
      <div class="row">
        <div class="title text-center">
          <h3>MAKE PERFECT YOUR IMAGINATION WITH YOUR COFFEE </h3>
          <p style="margin-top: 1px; ">Secangkir Kopi Lebih Jujur Darimu</p>
		  <p style="margin-bottom: 10px;"> Ia Pahit Tanpa Menyembunyikan Pahitnya</p>
		  <p> Ia Hitam Tanpa Mau Mengakui Warnanya </p>
        </div>
       <!--  <div class="col-md-2 col-sm-3">
          <a href="#" class="btn btn-primary">Read More</a>
        </div> -->
      </div>
    </div>
  </section>
  </div>

  <section>
    <div class="container">
	 <div style="text-align:center;">
      <div class="row">
        
        
       <div align="center" class="col-md-10 col-md-push-1 "> 
           <div >


          <div ><!--features_items-->
            <h2 class="title text-center">MENU</h2>
 <?php 

$query =  "SELECT * FROM `tblmeals`";
            $mydb->setQuery($query);
            $cur = $mydb->loadResultList();	
  foreach ($cur as $result) { 
  
   ?> 
		<ul    >

    <div class="col-md-4 col-sm-6 col-xs-1 " style="float:left; text-align:center; width:300px;height:60%;  margin-bottom:-80px;"> 
	

         <div  style="width:250px; height: 300px;margin-bottom:-150px;">   
            <a href="#" class="PHOTO"  	 data-toggle="modal" data-id="<?php  echo $result->MEALID; ?>"> <img  style="text-align:center;"  src="<?php  echo web_root.'admin/meals/'. $result->MEALPHOTO; ?>"></a>
       
		</div> 
		         <form   method="POST" action="cart/controller.php?action=add">
           <input type="hidden" name="PROPRICE" value="<?php  echo $result->MEALS; ?>">
              
              <p style=" width:250px; text-align:center;"><b ><?php  echo    $result->MEALS; ?> <br/>
			  
			  <br/>
                  
              </p>
               <div class="form-group">
                <div class="row">
                  
                </div>
              </div>

		</input>
		
	
           </form>
		<tr/>
        <div class="title text-center"   style="float:center; height:70px; width:160px;  color:#000033;"> 
		
           <figcaption>
		   
		   </figcaption>
         </div>
    </div> 	
	</ul>
<?php }  ?>
</div> 


<!-- product details modal -->
<div class="modal fade" id="photoModal" tabindex="-1"> 
   
</div>
 <!-- end -->
</div>
<!--features_items--> 
 
       
            <section id="call-to-action-2" style="background: #cf7d7d">
    
  </section>
        </div>
      </div>
    </div>
	</div>
  </section>