<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Home | Kedai Onel</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
  <link href="css/main.css" rel="stylesheet">
  <link href="css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
	

	  <style type="text/css">
      
	  @media screen and (max-width:720px){

	#maincontent{
		width: auto;
		float: none;
	}
	#sidebar{
		width: auto;
		float: none;
	}
}
	 .menu{
	
    border:1px solid #ccc;
    border-width:0px 0;
    list-style:none;
    margin:1;
    padding:0;
    text-align:center;
	font-family: Times New Roman;
}

	
.menu li{
    display:inline;
	font-family: Arial;
}
.menu a{
    display:inline-block;
    color:Black;
	font-family: Arial;
	font-size: 40px;
}
	 .menu2{
	
    border:1px solid #ccc;
    border-width:0px 0;
    list-style:none;
    margin:1;
    padding:0;
    text-align:center;
}

	
.menu2 li{
    display:inline;
}
.menu2 a{
    display:inline-block;
    color:Black;
	font-family: roboto;
	font-size: 40px;
}
.menu3{
    border-width:1px 0;
    list-style:none;
    margin:0;
    padding:0;
    text-align:center;
}

	
.menu3 li{
    display:inline;
	 text-align: center;
}
.menu3 a{
    display:inline-block;
    padding:5px;
    color:Black;
	font-family: roboto;
	font-size: 15px;
	text-align:left;
}
#footer{background:#f0f0f0;position:absolute;bottom:0;width:100%;
  color:#808080;}
</style>
</head><!--/head-->
 


 
<script type="text/javascript">
   

</script>
</head>

<body style="background-color:white" >

  <header id="header"><!--header-->
    <div class="header_top" style="background-color:#C0C0C0;color:maroon;"><!--header_top-->
      <div class="container">
        <div class="row">
          <div class="col-sm-6">
            <div class="contactinfo">
              <ul class="nav nav-pills">
			  
             <li><img href="#" style=" width:50px;"src="theme/download.png"  alt="logo"  /><li>
                <li><img href="theme/download.png"></a></li>
				<li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div><!--/header_top-->
    

   <marquee bgcolor="Black" scrollamount="15"  behavior="alternate" direction="right" height="50px" width="100%" style="color:white; font-family:Calibry; font-size:30px">  KEDAI ONEL 
           </marquee>
					 
    <!--/header-bottom-->
  </header><!--/header-->
<div style="margin-top: 0px;" class="navbar navbar-default navbar-static-top"    role="navigation" >

            <div class="container">
				<ul height="50px" width="50%" class="menu2" >
			<li >
                     <li  ><form action="<?php echo web_root?>index.php?q=product" method="POST" > 
              <div  class="search_box ">
                <input style="height:30px; width:200px; color:black;" type="text" name="search" placeholder="Search"/>
              </div>
            </form></li>
					 
                </li>
				</ul>
			</div>
			<div class="container">
			
			<ul class="menu3" >
			<nav class="menu3 navbar-expand-lg navbar-light bg-success mb-5">
  <div class="container">
			
			<ul class="menu3" >
			<li >
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
					<ul class="nav navbar-nav collapse navbar-collapse">  
					
                <li><a href="<?php echo web_root;?>" class="active">HOME</a></li>
				<li><a href="<?php web_root?>index.php?q=aboutus">ABOUT US </a></li>
           
                <li><a href="<?php web_root?>index.php?q=contact">CONTACT US</a></li>
              </ul>
                </li>
				</ul>
				
			</div>
</nav>
				</ul>
				
			</div>
			
			<div class="container">
          <?php 
            require_once $content; 
			
         ?> 
		 </div>
		
    <footer id="footer" style="position: auto;bottom: -200px;width:100%;padding;margin-top:0px; background-color:#202020;color:white"><!--Footer-->
    
  <div class="container">
    <div class="row">
      <div class="col-md-4 col-sm-4">
        <div class="widget">
          <h4 style="font-family:Segoe UI;color:#3399FF" class="widgetheading">ABOUT THE Kedai</h4>
        
        <ul class="link-list">
            <li><a style="font-family:Segoe UI;color:#9FDAE7" href="<?php echo web_root; ?>index.php?q=aboutus">About Us</a></li>
          </ul>

		  
        </div>
      </div>
      <div class="col-md-4 col-sm-4">
        <div class="widget">
          <h4  style="font-family:Segoe UI;color:#3399FF" class="widgetheading">Location</h4>
          <ul style="font-family:Segoe UI;color:black" class="link-list">
            <li><a style="font-family:Segoe UI;color:#9FDAE7" href="<?php echo web_root; ?>index.php?q=aboutus">About Us</a></li>
          </ul>
        </div>
      </div>
<!--       <div class="col-md-4 col-sm-4">
        <div class="widget">
          <h5 class="widgetheading">Latest posts</h5>
          <ul class="link-list">
             
          </ul>
        </div>
      </div> -->
      
    </div>
	<div class="row">
 <div class="col-lg-6">
	<div class="copyright">
            <p>
              <span> Kedai Onel <img style=" width:4%;height:100%;"src="theme/download.png"  alt="logo"  />
            </p>
          </div>
        </div>		
  <div class="container">
    <div class="row">
       <div class="col-lg-5">
          <ul class="social-network">
           <a href="#" data-placement="top" title="Facebook"><i class="fa fa-facebook"></i></a>
            <a href="#" data-placement="top" title="Twitter"><i class="fa fa-instagram"></i></a>
          </ul>
        </div>
      
    </div>
  </div>
    </div>
  </div>
  </footer><!--/Footer-->
  </div>

 <!-- modalorder -->
 <div class="modal fade" id="myOrdered">
 </div>


 <?php include "LogSignModal.php"; ?> 
<!-- end -->
 
    <!-- jQuery -->
    <script src="<?php echo web_root; ?>jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo web_root; ?>js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript --> 
    <!-- DataTables JavaScript -->
    <script src="<?php echo web_root; ?>js/jquery.dataTables.min.js"></script>
    <script src="<?php echo web_root; ?>js/dataTables.bootstrap.min.js"></script>


<script type="text/javascript" language="javascript" src="<?php echo web_root; ?>js/ekko-lightbox.js"></script> 
<script type="text/javascript" src="<?php echo web_root; ?>js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
<script type="text/javascript" src="<?php echo web_root; ?>js/locales/bootstrap-datetimepicker.uk.js" charset="UTF-8"></script>

   
<script src="<?php echo web_root; ?>js/jquery.scrollUp.min.js"></script>
<script src="<?php echo web_root; ?>js/price-range.js"></script>
<script src="<?php echo web_root; ?>js/jquery.prettyPhoto.js"></script>
<script src="<?php echo web_root; ?>js/main.js"></script> 

  <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>
    <script type="text/javascript" src="js/gmaps.js"></script>
  <script src="js/contact.js"></script>

    <!-- Custom Theme JavaScript --> 
<script type="text/javascript" language="javascript" src="<?php echo web_root; ?>js/janobe.js"></script> 
 <script type="text/javascript">
  $(document).on("click", ".proid", function () {
    // var id = $(this).attr('id');
      var proid = $(this).data('id')
    // alert(proid)
       $(".modal-body #proid").val( proid )

      });

</script>
 <script>
    // tooltip demo
    $('.tooltip-demo').tooltip({
        selector: "[data-toggle=tooltip]",
        container: "body"
    })

    // popover demo
    $("[data-toggle=popover]")
        .popover()
    </script>


      <script>
        $('.carousel').carousel({
            interval: 100 //changes the speed
        })
    </script>

<script type="text/javascript">


$('#date_picker').datetimepicker({
  format: 'mm/dd/yyyy',
    language:  'en',
    weekStart: 1,
    todayBtn:  1,
    autoclose: 1,
    todayHighlight: 1,
    startView: 2,
    minView: 2,
    forceParse: 0
    });

 
 
 
function validatedate(){ 
 
 

    var todaysDate = new Date() ;

    var txtime =  document.getElementById('ftime').value
    // var myDate = new Date(dateme); 

    var tprice = document.getElementById('alltot').value 
    var BRGY = document.getElementById('BRGY').value
    var onum = document.getElementById('ORDERNUMBER').value

     
     var mytime = parseInt(txtime)  ;
     var todaytime =  todaysDate.getHours()  ;
       if (txtime==""){
     alert("You must set the time enable to submit the order.")
     }else 
     if (mytime<todaytime){ 
        alert("Selected time is invalid. Set another time.")
      }else{
        window.location = "index.php?page=7&price="+tprice+"&time="+txtime+"&BRGY="+BRGY+"&ordernumber="+onum; 
      }
  }
</script>  


    <script type="text/javascript">
  $('.form_curdate').datetimepicker({
        language:  'en',
        weekStart: 1,
        todayBtn:  1,
        autoclose: 1,
        todayHighlight: 1,
        startView: 2,
        minView: 2,
        forceParse: 0
    });
  $('.form_bdatess').datetimepicker({
        language:  'en',
        weekStart: 1,
        todayBtn:  1,
        autoclose: 1,
        todayHighlight: 1,
        startView: 2,
        minView: 2,
        forceParse: 0
    });
</script>
<script>
 


  function checkall(selector)
  {
    if(document.getElementById('chkall').checked==true)
    {
      var chkelement=document.getElementsByName(selector);
      for(var i=0;i<chkelement.length;i++)
      {
        chkelement.item(i).checked=true;
      }
    }
    else
    {
      var chkelement=document.getElementsByName(selector);
      for(var i=0;i<chkelement.length;i++)
      {
        chkelement.item(i).checked=false;
      }
    }
  }
   function checkNumber(textBox){
        while (textBox.value.length > 0 && isNaN(textBox.value)) {
          textBox.value = textBox.value.substring(0, textBox.value.length - 1)
        }
        textBox.value = trim(textBox.value);
      }
      //
      function checkText(textBox)
      {
        var alphaExp = /^[a-zA-Z]+$/;
        while (textBox.value.length > 0 && !textBox.value.match(alphaExp)) {
          textBox.value = textBox.value.substring(0, textBox.value.length - 1)
        }
        textBox.value = trim(textBox.value);
      }
  

       
  </script>     

</body>
</html>