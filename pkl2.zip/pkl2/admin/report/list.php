<?php
   if (!isset($_SESSION['ADMIN_USERID'])){
      redirect(web_root."index.php");
     }

		check_message(); 
		?> 
		 
		<div class="row">
       	 <div class="col-lg-12">
            <h2 class="page-header">REPORTS  </h2>
       		</div>
        	<!-- /.col-lg-12 -->
   		 </div>
		 <div class="row" style="margin:0;text-align:center;">
<form  action="index.php" method="post">  
	 <div class="col-lg-6"></div>
   <div class="col-lg-4"> 
	 <div class="col-md-12"  > 
 	    <div class="row">
		  <div class="col-md-6">
				<div class="form-group input-group"> 
	                <label>From::</label> 
	                <input type="text" data-date="" data-date-format="yyyy-mm-dd" data-link-field="any" 
                           data-link-format="yyyy-mm-dd"
                           name="date_pickerfrom" id="date_pickerfrom"  
                           value="<?php echo isset($_POST['date_pickerfrom']) ? $_POST['date_pickerfrom'] :'';?>"
                            readonly="true" class="date_pickerfrom input-sm form-control">
	                <span class="input-group-btn">
	                    <i class="fa  fa-calendar" ></i> 
	                </span>
	            </div>
				</div>
					<div class="col-md-6">
					<div class="form-group input-group"> 
		                <label>To::</label> 
		                <input type="text" data-date="" data-date-format="yyyy-mm-dd" data-link-field="any" 
                           data-link-format="yyyy-mm-dd"
                           name="date_pickerto" id="date_pickerto" 
                           value="<?php echo isset($_POST['date_pickerto']) ? $_POST['date_pickerto'] : '';?>" 
                            readonly="true" class="date_pickerto form-control  input-sm">
		                <span class="input-group-btn">
		                    <i class="fa  fa-calendar" ></i> 
		                </span>

		            </div>
				</div>
	    </div> 
	 </div>
   </div>
   <div class="col-lg-2">  
 	    <div class="row">
		  <div class="col-md-12">
			 <div class="form-group input-group" style="margin-top:25px;">  
                <button class="btn btn-primary btn-sm" name="submit" type="submit" >Seaarch <i class="fa fa-search"></i>
                </button> 
            </div>
		   </div>  
	    </div> 
	 </div>
</form>
</div>
		 <div class="row">
					<span id="printout">
					<div class="page-header" style="text-align:center;" ><h1>List of Ordered Products</h1>
		<div>Inclusive Dates: From : <?php echo isset($_POST['date_pickerfrom']) ? $_POST['date_pickerfrom'] :'';?> - To : <?php echo isset($_POST['date_pickerto']) ? $_POST['date_pickerto'] : '';?> </div>
	</div>
			    <form Method="POST">  	
			    <div class="table-responsive">				
				<table id="dash-table"  class="table table-striped table-bordered table-hover "  style="font-size:12px" cellspacing="0" >
					
				  <thead style="font-size: 18px;">
				  	<tr>  
				  		<th style="text-align: center;">Photo</th>  
				  		<th>Menu Description</th>
				  		<th>Categories</th>  
						<th style="text-align: center;">Action</th> 
				  		<th>Price</th> 
				  		
				  	</tr>	
				  </thead> 	

			  <tbody>
				  	<?php 
					if(isset($_POST['submit'])){
				  		$query = "SELECT * FROM tblorders WHERE  DATE(DATEORDERED) >= '". date_format(date_create($_POST['date_pickerfrom']),'Y-m-d')."' AND DATE(DATEORDERED) <= '". date_format(date_create($_POST['date_pickerto']),'Y-m-d')."' GROUP BY `DESCRIPTION`";
				  		$mydb->setQuery($query);
				  		$cur = $mydb->loadResultList();

						foreach ($cur as $result) { 
				  		echo '<tr>';
				  		// echo '<td width="3%" align="center"></td>'; 
				  		echo '<td style="font-size:15px;">'.$result->DATEORDERED.'</a></td>';
				  		echo '<td style="font-size:15px;">'.$result->DESCRIPTION.'</a></td>';
						echo '<td style="font-size:15px;">'.$result->REMARKS.'</a></td>';
						echo '<td style="font-size:15px;">'.$result->QUANTITY.'</a></td>';
				  		echo '<td style="font-size:15px;" width="100px"> Rp.  '.  number_format($result->PRICE).'</td>';
						
						}
					}						
				  	?>
				  </tbody>
				</table>

				</div>
				</form>
						</span>
						<div class="row">
		<div class="col-md-12">
			<div class="col-md-2"> 	
			<button onclick="tablePrint();" class="btn btn-primary"><i class="fa fa-print"></i> Print Report</button>
 		</div>
	  </div>
	</div>
						</div>
<script>
    $(document).ready(function() {  
         var t = $('#example').DataTable( {
        "columnDefs": [ {
            "searchable": false,
            "orderable": false,
            "targets": 0
        } ],  
          // "sort": false,
        //ordering start at column 1
        "order": [[ 6, 'desc' ]]
    } );
 
    t.on( 'order.dt search.dt', function () {
        t.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
            cell.innerHTML = i+1;
        } );
    } ).draw();
} );
 


     
 $(document).ready(function() {
    $('#dash-table').DataTable({
                responsive: true ,
                  "sort": false
        });
 
    });


 
$('.date_pickerfrom').datetimepicker({
  format: 'mm/dd/yyyy',
   startDate : '01/01/2000', 
    language:  'en',
    weekStart: 1,
    todayBtn:  1,
    autoclose: 1,
    todayHighlight: 1, 
    startView: 2,
    minView: 2,
    forceParse: 0 

    });


$('.date_pickerto').datetimepicker({
  format: 'mm/dd/yyyy',
   startDate : '01/01/2000', 
    language:  'en',
    weekStart: 1,
    todayBtn:  1,
    autoclose: 1,
    todayHighlight: 1, 
    startView: 2,
    minView: 2,
    forceParse: 0   

    });
// $(function() {
//         var dates = $( "#date_pickerfrom, #date_pickerto" ).datepicker({                                   
//             defaultDate:'',
//             changeMonth: true,
//             numberOfMonths: 1,
//             onSelect: function( selectedDate ) {
//             var now =Date();
//                 var option = this.id == "from" ? "minDate" : "maxDate",
//                     instance = $(this).data("datepicker"),
//                     date = $.datepicker.parseDate(
//                         instance.settings.dateFormat ||
//                         $.datepicker._defaults.dateFormat,
//                         selectedDate, instance.settings );
//                 dates.not( this ).datepicker( "option", option, date );
//             }
//         });

 
$('#date_picker').datetimepicker({
  format: 'mm/dd/yyyy',
    language:  'en',
    weekStart: 1,
    todayBtn:  1,
    autoclose: 1,
    todayHighlight: 1,
    startView: 2,
    minView: 2,
    forceParse: 0,
     changeMonth: true,
      changeYear: true,
      yearRange: '1945:'+(new Date).getFullYear() 
    });




</script> 
<script>
function tablePrint(){  
    var display_setting="toolbar=no,location=no,directories=no,menubar=no,";  
    display_setting+="scrollbars=no,width=500, height=500, left=100, top=25";  
    var content_innerhtml = document.getElementById("printout").innerHTML;  
    var document_print=window.open("","",display_setting);  
    document_print.document.open();  
    document_print.document.write('<body style="font-family:Calibri(body);  font-size:8px;" onLoad="self.print();self.close();" >');  
    document_print.document.write(content_innerhtml);  
    document_print.document.write('</body></html>');  
    document_print.print();  
    document_print.document.close();  
    return false;  
    } 
	$(document).ready(function() {
		oTable = jQuery('#list').dataTable({
		"bJQueryUI": true,
		"sPaginationType": "full_numbers"
		} );
	});	

		
</script>