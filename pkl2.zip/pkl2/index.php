<?php
require_once ("include/initialize.php");
// if(isset($_SESSION['IDNO'])){
// 	redirect(web_root.'index.php');

// }

$content='home.php';
$view = (isset($_GET['p']) && $_GET['q'] != '') ? $_GET['q'] : '';




switch ($view) {
		case 'login' :
        $title="login";	
		$content='admin/login.php';		
		break;
		case 'aboutus' :
        $title="About Us";	
		$content='aboutus.php';		
		break;
		case 'contact' :
        $title="contact";	
		$content='contact.php';		
		break;
	case 'product' :
        $title="Products";	
		$content='menu.php';		
		break;
 	
 	

	
 	case 'single-item' :
        $title="Product";	
		$content='single-item.php';		
		break;

	case 'recoverpassword' :
        $title="Recover Password";	
		$content='passwordrecover.php';		
		break;
	default :
	    $title="Home";	
		$content ='home.php';		

}

       
    
 
require_once("theme/templates.php");
 

?>

